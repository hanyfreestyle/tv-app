-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2024 at 08:27 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apptv_20240102`
--

-- --------------------------------------------------------

--
-- Table structure for table `config_def_photos`
--

CREATE TABLE `config_def_photos` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_def_photos`
--

INSERT INTO `config_def_photos` (`id`, `cat_id`, `photo`, `photo_thum_1`, `photo_thum_2`, `postion`, `created_at`, `updated_at`) VALUES
(1, 'light-logo', 'images/def-photo/light-logo-AJG4FyEGq8.webp', NULL, NULL, 2, '2023-09-03 15:03:13', '2023-09-03 15:04:25'),
(2, 'dark-logo', 'images/def-photo/dark-logo-yHavtqPGm6.webp', NULL, NULL, 1, '2023-09-03 15:04:17', '2023-09-03 15:04:25'),
(6, 'contact-from', 'images/def-photo/contact-from-taOS5rT9SI.webp', NULL, NULL, 0, '2023-09-06 19:37:35', '2023-09-06 19:37:35'),
(14, 'form_login', 'images/def-photo/cust-login-5vzy5IZjUZ.webp', NULL, NULL, 0, '2023-09-29 00:45:03', '2023-09-29 03:16:32'),
(15, 'form_sign_up', 'images/def-photo/form-sign-up-AlQFSq2P80.webp', NULL, NULL, 0, '2023-09-29 03:17:07', '2023-09-29 03:33:50'),
(16, 'faq_def', 'images/def-photo/faq-def-l6MK9ENwYI.webp', 'images/def-photo/faq-def-ueQf4S6QTB.webp', NULL, 0, '2024-01-02 15:24:52', '2024-01-04 14:54:32');

-- --------------------------------------------------------

--
-- Table structure for table `config_settings`
--

CREATE TABLE `config_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `web_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web_status` int(11) NOT NULL DEFAULT 1,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `def_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_api` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `download_app` int(11) NOT NULL DEFAULT 0,
  `top_offer` int(11) NOT NULL DEFAULT 0,
  `apple` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `android` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `windows` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_send_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_settings`
--

INSERT INTO `config_settings` (`id`, `web_url`, `web_status`, `logo`, `favicon`, `phone_num`, `whatsapp_num`, `phone_text`, `whatsapp_text`, `facebook`, `youtube`, `twitter`, `instagram`, `linkedin`, `def_url`, `google_api`, `download_app`, `top_offer`, `apple`, `android`, `windows`, `telegram_key`, `telegram_group`, `telegram_phone`, `whatsapp_key`, `whatsapp_send_to`, `notes`, `created_at`, `updated_at`) VALUES
(1, '#', 1, '', '', '01006180117', '201006180117', '+1 (612) 707-6852', '0100-6180-117', 'https://www.facebook.com/Etman.Group', 'https://www.youtube.com/channel/UC8GkiBf6L9bogsUtx0PEgTg', '#', 'https://www.instagram.com/etmangroup.eg/', 'https://www.linkedin.com/company/etman-group/', 'https://etman-group.com', 'AIzaSyDWuKOMM4hm_uBnQjqQufaLlHSN2QS_4Qo', 1, 1, 'https://www.apple.com/store', 'https://play.google.com/store/apps?hl=en&amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;gl=US', 'https://www.microsoft.com/en-eg/store/', '6313317483:AAEooBTEFel1ej1uaDpXcZzCrbX_ID3aYEw', '-1001989217795', '200119925', '8592e88ef28ba32bd5e5b59c11a59f864a898e53b94cbacb04a87dc1f0c377c1887491212d364739', '01010881921', '8592e88ef28ba32bd5e5b59c11a59f864a898e53b94cbacb04a87dc1f0c377c1887491212d364739\r\n01010881921\r\n\r\n6313317483:AAEooBTEFel1ej1uaDpXcZzCrbX_ID3aYEw\r\n-1001989217795\r\n200119925\r\n\r\nsss', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_setting_translations`
--

CREATE TABLE `config_setting_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closed_mass` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_setting_translations`
--

INSERT INTO `config_setting_translations` (`id`, `setting_id`, `locale`, `name`, `g_title`, `g_des`, `closed_mass`, `offer`) VALUES
(1, 1, 'ar', 'عتمان جروب', 'عنوان الصفحة يكتب هنا', 'وصف الصفحة يكتب هنا', 'زوار موقعنا الكرام ... تلبية لرغبتكم الكريمة فى تطوير الموقع \r\nوليرتقى للمستوى العالمى فى تقديم كل ما يهمكم \r\nنحن بصدد تطوير الموقع كليا ليتناسب معكم\r\nادارة الموقع', 'شحن مجانى للطلبات اكثر من 2500 جنية داخل الاسكندرية'),
(2, 1, 'en', 'Tv App', 'The title of the site is written here', 'The description of the site is written here', 'Dear visitors ... In response to your generous desire to develop the site ... and to rise to the international level in providing everything that interests you ... \r\nWe are in the process of developing the website completely to suit you ..\r\nSite Administration', 'Free Ground Shipping Over  2500 LE');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filters`
--

CREATE TABLE `config_upload_filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `convert_state` int(11) NOT NULL DEFAULT 1,
  `quality_val` int(11) NOT NULL DEFAULT 85,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#ffffff',
  `greyscale` int(11) NOT NULL DEFAULT 0,
  `flip_state` int(11) NOT NULL DEFAULT 0,
  `flip_v` int(11) NOT NULL DEFAULT 0,
  `blur` int(11) NOT NULL DEFAULT 0,
  `blur_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pixelate` int(11) NOT NULL DEFAULT 0,
  `pixelate_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '5',
  `text_state` int(11) NOT NULL DEFAULT 0,
  `text_print` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_opacity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_state` int(11) NOT NULL DEFAULT 0,
  `watermark_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filters`
--

INSERT INTO `config_upload_filters` (`id`, `name`, `type`, `convert_state`, `quality_val`, `new_w`, `new_h`, `canvas_back`, `greyscale`, `flip_state`, `flip_v`, `blur`, `blur_size`, `pixelate`, `pixelate_size`, `text_state`, `text_print`, `font_size`, `font_path`, `font_color`, `font_opacity`, `text_position`, `watermark_state`, `watermark_img`, `watermark_position`, `state`, `created_at`, `updated_at`) VALUES
(1, 'NoEdit', 1, 1, 85, 100, 100, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(2, 'DefPhoto', 4, 1, 85, 800, 420, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(3, 'FaqCategory', 4, 1, 85, 600, 400, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2024-01-04 14:49:54'),
(4, 'FaqQuestion', 2, 1, 85, 1024, 700, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2024-01-03 19:33:41'),
(5, 'PhotoGallery', 4, 1, 85, 1024, 768, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filter_sizes`
--

CREATE TABLE `config_upload_filter_sizes` (
  `id` int(10) UNSIGNED NOT NULL,
  `filter_id` int(10) UNSIGNED NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `get_more_option` int(11) NOT NULL DEFAULT 0,
  `get_add_text` int(11) NOT NULL DEFAULT 0,
  `get_watermark` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filter_sizes`
--

INSERT INTO `config_upload_filter_sizes` (`id`, `filter_id`, `type`, `new_w`, `new_h`, `canvas_back`, `get_more_option`, `get_add_text`, `get_watermark`) VALUES
(1, 2, 4, 500, 335, NULL, 0, 0, 0),
(2, 4, 2, 800, 400, '#FFFFFF', 0, 0, 0),
(3, 5, 4, 800, 600, '#ffffff', 0, 0, 0),
(4, 5, 4, 320, 240, '#ffffff', 0, 0, 0),
(8, 3, 4, 300, 200, '#FFFFFF', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacies`
--

CREATE TABLE `config_web_privacies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacies`
--

INSERT INTO `config_web_privacies` (`id`, `name`, `postion`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 'شروط وسياسة الخصوصية', 2, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(3, 'جمع المعلومات واستخدامها', 3, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(4, 'أنواع البيانات المجمعة', 4, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(5, 'بيانات الاستخدام', 5, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(6, 'تتبع و ملفات تعريف الارتباط', 6, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(7, 'استخدام البيانات', 7, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(8, 'نقل البيانات', 8, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(9, 'الكشف عن البيانات', 9, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(10, 'أمن البيانات', 10, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(11, 'مقدمي الخدمة', 11, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(12, 'تحليلات', 12, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(13, 'روابط لمواقع أخرى', 13, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(14, 'خصوصية الأطفال', 14, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(15, 'تغييرات سياسة الخصوصية', 15, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(16, 'اتصل بنا', 16, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57');

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacy_translations`
--

CREATE TABLE `config_web_privacy_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `privacy_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `h2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lists` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacy_translations`
--

INSERT INTO `config_web_privacy_translations` (`id`, `privacy_id`, `locale`, `h1`, `h2`, `des`, `lists`) VALUES
(3, 2, 'ar', 'شروط وسياسة الخصوصية', '', 'تقوم شركة [CompanyName] (\"نحن\" أو \"نحن\" أو \"موقعنا\") بتشغيل [WebSiteName]  (\"الموقع الالكترونى\").\r\nتُعرفك هذه الصفحة بسياساتنا المتعلقة بجمع البيانات الشخصية واستخدامها والكشف عنها عند استخدامك للخدمة والأختيارات المرتبطة بهذه البيانات. \r\nسياسة الخصوصية لشركة [CompanyName]\r\nنستخدم بياناتك لتوفير الخدمة وتحسينها. باستخدام الخدمة، فإنك توافق على جمع واستخدام المعلومات وفقًا لهذه السياسة. ما لم يتم تحديد خلاف ذلك في سياسة الخصوصية، فإن المصطلحات المستخدمة في سياسة الخصوصية لها نفس المعاني كما في الشروط والأحكام الخاصة بنا، والتي يمكن الوصول إليها من [WebSiteName]', ''),
(4, 2, 'en', 'Privacy Policy', '', ' [CompanyName] (\"us\", \"we\", or \"our\") operates the [WebSiteName] website (the \"Service\").\r\nThis page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. Our Privacy Policy for [CompanyName]\r\nWe use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from  [WebSiteName]', ''),
(5, 3, 'ar', 'جمع المعلومات واستخدامها', '', 'نقوم بتجميع أنواع مختلفة من المعلومات لأغراض متنوعة لتوفير وتحسين خدماتنا لك.', ''),
(6, 3, 'en', 'Information Collection And Use', '', 'We collect several different types of information for various purposes to provide and improve our Service to you.', ''),
(7, 4, 'ar', 'أنواع البيانات المجمعة', 'بيانات شخصية', 'أثناء استخدام خدماتنا ، قد نطلب منك تزويدنا بمعلومات تعريف شخصية معينة يمكن استخدامها للاتصال أو التعرف عليك (&quot;البيانات الشخصية&quot;). قد تتضمن معلومات \r\nالتعريف الشخصية ، على سبيل المثال لا الحصر ، ما يلي:', 'عنوان بريد الكتروني\r\nالاسم الأول واسم العائلة\r\nرقم الهاتف\r\nالعنوان ، الولاية ، المقاطعة ، الرمز البريدي / المدينة ، المدينة\r\nملفات تعريف الارتباط وبيانات الاستخدام'),
(8, 4, 'en', 'Types of Data Collected', 'Personal Data', 'While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (&quot;Personal Data&quot;). Personally identifiable information may include, but is not limited to :', 'Email address\r\nFirst name and last name\r\nPhone number\r\nAddress, State, Province, ZIP/Postal code, City\r\nCookies and Usage Data'),
(9, 5, 'ar', 'بيانات الاستخدام', '', 'يجوز لنا أيضًا جمع المعلومات حول كيفية الوصول إلى الخدمة واستخدامها (&quot;بيانات الاستخدام&quot;). قد تتضمن بيانات الاستخدام هذه معلومات مثل عنوان بروتوكول الإنترنت الخاص بجهاز الكمبيوتر (مثل عنوان IP) ، ونوع المتصفح، وإصدار المتصفح، وصفحات الخدمة التي تزورها، ووقت وتاريخ زيارتك، والوقت الذي يقضيه في تلك الصفحات، ومعرفات الجهاز وغيرها من البيانات التشخيصية.', ''),
(10, 5, 'en', 'Usage Data', '', 'We may also collect information how the Service is accessed and used (&quot;Usage Data&quot;). This Usage Data may include information such as your computer\'s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.', ''),
(11, 6, 'ar', 'تتبع و ملفات تعريف الارتباط', '', 'نحن نستخدم ملفات تعريف الارتباط وتقنيات التتبع المماثلة لتتبع النشاط على الخدمة لدينا مع الاحتفاظ بمعلومات معينة.\r\nملفات تعريف الارتباط عبارة عن ملفات تحتوي على كمية صغيرة من البيانات التي قد تتضمن معرفًا فريدًا مجهول الهوية. يتم إرسال ملفات تعريف الارتباط إلى متصفحك من موقع الويب وتخزينها على جهازك. تقنيات التتبع المستخدمة هي منارات وعلامات ونصوص لجمع المعلومات وتتبعها ولتحسين خدمتنا وتحليلها.\r\nيمكنك إرشاد المتصفح الخاص بك لرفض جميع ملفات تعريف الارتباط أو للإشارة إلى إرسال ملف تعريف الارتباط. ومع ذلك، إذا كنت لا تقبل ملفات تعريف الارتباط، فقد لا تتمكن من استخدام بعض أجزاء من خدمتنا.\r\n\r\nأمثلة على ملفات تعريف الارتباط التي نستخدمها:', 'نحن نستخدم ملفات تعريف الارتباط الخاصة بالجلسات لتشغيل الخدمة الخاصة بنا.\r\nنحن نستخدم ملفات تعريف الارتباط التفضيلية لتذكر تفضيلاتك والإعدادات المختلفة.\r\nنحن نستخدم ملفات تعريف الارتباط للأمان لأغراض أمنية.'),
(12, 6, 'en', 'Tracking &amp; Cookies Data', '', 'We use cookies and similar tracking technologies to track the activity on our Service and hold certain information.\r\nCookies are files with small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Tracking technologies also used are beacons, tags, and scripts to collect and track information and to improve and analyze our Service.\r\nYou can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.\r\n\r\nExamples of Cookies we use:', 'Session Cookies. We use Session Cookies to operate our Service.\r\nPreference Cookies. We use Preference Cookies to remember your preferences and various settings.\r\nSecurity Cookies. We use Security Cookies for security purposes.'),
(13, 7, 'ar', 'استخدام البيانات', '', 'تستخدم [CompanyName] البيانات التي تم جمعها لأغراض مختلفة :', 'لإعلامك عن تغييرات لخدمتنا.\r\nللسماح لك بالمشاركة في الميزات التفاعلية في خدمتنا عندما تختار القيام بذلك.\r\nلتوفير رعاية العملاء والدعم.\r\nلتقديم تحليل أو معلومات قيمة حتى نتمكن من تحسين الخدمة.\r\nلمراقبة استخدام الخدمة.\r\nللكشف عن المشكلات الفنية ومنعها ومعالجتها.'),
(14, 7, 'en', 'Use of Data', '', '[CompanyName] uses the collected data for various purposes:', 'To provide and maintain the Service.\r\nTo notify you about changes to our Service.\r\nTo allow you to participate in interactive features of our Service when you choose to do so.\r\nTo provide customer care and support.\r\nTo provide analysis or valuable information so that we can improve the Service.\r\nTo monitor the usage of the Service.\r\nTo detect, prevent and address technical issues.'),
(15, 8, 'ar', 'نقل البيانات', '', 'قد يتم نقل معلوماتك - بما في ذلك البيانات الشخصية - إلى أجهزة الكمبيوتر الموجودة خارج الولاية أو المقاطعة أو الدولة أو الولاية الحكومية الأخرى التي قد تختلف فيها قوانين حماية البيانات عن تلك الخاصة باختصاصك القضائي.\r\nإذا كنت متواجدًا خارج مصر واخترت تقديم معلومات لنا، يرجى ملاحظة أننا نقوم بنقل البيانات، بما في ذلك البيانات الشخصية، إلى مصر ومعالجتها هناك.\r\nإن موافقتك على سياسة الخصوصية هذه والتي يتبعها تقديمك لهذه المعلومات تمثل موافقتك على هذا النقل \r\nسوف تتخذ [CompanyName] جميع الخطوات الضرورية بشكل معقول لضمان التعامل مع بياناتك بشكل آمن ووفقًا لسياسة الخصوصية هذه ولن يتم نقل بياناتك الشخصية إلى منظمة أو دولة ما لم تكن هناك ضوابط كافية في مكان بما في ذلك أمن البيانات الخاصة بك وغيرها من المعلومات الشخصية.', ''),
(16, 8, 'en', 'Transfer Of Data', '', 'Your information, including Personal Data, may be transferred to — and maintained on — computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ than those from your jurisdiction.\r\nIf you are located outside Egypt and choose to provide information to us, please note that we transfer the data, including Personal Data, to Egypt and process it there.\r\nYour consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.\r\n[CompanyName] will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organization or a country unless there are adequate controls in place including the security of your data and other personal information.', ''),
(17, 9, 'ar', 'الكشف عن البيانات', 'المتطلبات القانونية', 'يحق لـ [CompanyName] الإفصاح عن بياناتك الشخصية بحسن نية من أن هذا الإجراء ضروري من أجل:', 'للامتثال لالتزام قانوني\r\nلحماية والدفاع عن حقوق أو ملكية [CompanyName]\r\nلمنع أو التحقيق في أي مخالفات محتملة تتعلق بالخدمة.\r\nلحماية السلامة الشخصية لمستخدمي الخدمة أو الجمهور.\r\nللحماية من المسؤولية القانونية.'),
(18, 9, 'en', 'Disclosure Of Data', 'Legal Requirements', '[CompanyName] may disclose your Personal Data in the good faith belief that such action is necessary to:', 'To comply with a legal obligation.\r\nTo protect and defend the rights or property of [CompanyName]\r\nTo prevent or investigate possible wrongdoing in connection with the Service.\r\nTo protect the personal safety of users of the Service or the public.\r\nTo protect against legal liability.'),
(19, 10, 'ar', 'أمن البيانات', '', 'أمان بياناتك مهم بالنسبة لنا، ولكن تذكر أنه لا توجد طريقة للإرسال عبر الإنترنت، أو طريقة التخزين الإلكترونية آمنة ١٠٠٪. بينما نسعى جاهدين لاستخدام وسائل مقبولة تجاريًا لحماية بياناتك الشخصية، لا يمكننا ضمان أمانها المطلق.', ''),
(20, 10, 'en', 'Security Of Data', '', 'The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.', ''),
(21, 11, 'ar', 'مقدمي الخدمة', '', 'يجوز لنا أن نوظف شركات وأفراد من أطراف ثالثة لتسهيل خدمتنا (&quot;مزودي الخدمة&quot;)، أو تقديم الخدمة نيابة عنا، لأداء الخدمات المتعلقة بالخدمة أو لمساعدتنا في تحليل كيفية استخدام خدمتنا.\r\nهذه الأطراف الثالثة لديها حق الوصول إلى بياناتك الشخصية فقط لأداء هذه المهام نيابة عنا وتكون ملزمة بعدم الكشف عنها أو استخدامها لأي غرض آخر.', ''),
(22, 11, 'en', 'Service Providers', '', 'We may employ third party companies and individuals to facilitate our Service (&quot;Service Providers&quot;), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used.\r\nThese third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.', ''),
(23, 12, 'ar', 'تحليلات', '', 'قد نستخدم مزودي خدمة من جهات خارجية لمراقبة وتحليل استخدام خدماتنا.', ''),
(24, 12, 'en', 'Analytics', '', 'We may use third-party Service Providers to monitor and analyze the use of our Service.', ''),
(25, 13, 'ar', 'روابط لمواقع أخرى', '', 'قد تحتوي خدمتنا على روابط إلى مواقع أخرى لا يتم تشغيلها من قبلنا. إذا نقرت على رابط جهة خارجية، فسيتم توجيهك إلى موقع الطرف الثالث هذا. ننصحك بشدة بمراجعة سياسة الخصوصية لكل موقع تزوره.\r\n\r\nليس لدينا أي سيطرة ولا نتحمل أي مسؤولية عن المحتوى أو سياسات الخصوصية أو الممارسات الخاصة بأي مواقع أو خدمات خاصة بطرف ثالث.', ''),
(26, 13, 'en', 'Links To Other Sites', '', 'Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party\'s site. We strongly advise you to review the Privacy Policy of every site you visit.\r\n\r\nWe have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services.', ''),
(27, 14, 'ar', 'خصوصية الأطفال', '', 'لا تتناول خدمتنا أي شخص دون سن ١٨ عامًا (&quot;الأطفال&quot;).\r\nنحن لا نجمع معلومات التعريف الشخصية من أي شخص دون سن ١٨ عامًا. إذا كنت أحد الوالدين أو الوصي وكنت على علم بأن أطفالك قد زودونا ببيانات شخصية، يرجى الاتصال بنا. إذا علمنا أننا جمعنا بيانات شخصية من الأطفال دون التحقق من موافقة الوالدين، فإننا نتخذ خطوات لإزالة تلك المعلومات من خوادمنا.', ''),
(28, 14, 'en', 'Children\'s Privacy', '', 'Our Service does not address anyone under the age of 18 (&quot;Children&quot;).\r\nWe do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your Children has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.', ''),
(29, 15, 'ar', 'تغييرات سياسة الخصوصية', '', 'يجوز لنا تحديث سياسة الخصوصية الخاصة بنا من وقت لآخر. سنعلمك بأي تغييرات عن طريق نشر سياسة الخصوصية الجديدة على هذه الصفحة.\r\nسنخبرك عبر البريد الإلكتروني و/ أو بإشعار بارز في خدمتنا، قبل أن يصبح التغيير ساريًا وتحديث &quot;تاريخ الفعالية&quot; في أعلى سياسة الخصوصية هذه.\r\nننصحك بمراجعة سياسة الخصوصية هذه بشكل دوري لأية تغييرات. تسري التغييرات التي تطرأ على سياسة الخصوصية هذه عند نشرها على هذه الصفحة.', ''),
(30, 15, 'en', 'Changes To This Privacy Policy', '', 'We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.\r\n\r\nWe will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the &quot;effective date&quot; at the top of this Privacy Policy.\r\n\r\nYou are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.', ''),
(31, 16, 'ar', 'اتصل بنا', '', 'إذا كان لديك أي أسئلة حول سياسة الخصوصية هذه، يرجى الاتصال بنا:', 'البريد الإلكتروني : info@etman-group.com'),
(32, 16, 'en', 'Contact Us', '', 'If you have any questions about this Privacy Policy, please contact us:', 'Email:info@etman-group.com');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us_forms`
--

CREATE TABLE `contact_us_forms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `data_cities`
--

CREATE TABLE `data_cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_cities`
--

INSERT INTO `data_cities` (`id`, `name`, `name_en`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'القاهرة', 'Cairo', 1, NULL, NULL, NULL),
(2, 'القاهرة الجديدة', 'New Cairo', 1, NULL, NULL, NULL),
(3, 'الاسكندرية', 'Alexandria', 1, NULL, NULL, NULL),
(4, 'الاسماعيلية', 'Ismailia', 1, NULL, NULL, NULL),
(5, 'اسوان', 'Aswan', 1, NULL, NULL, NULL),
(6, 'اسيوط', 'Asyut', 1, NULL, NULL, NULL),
(7, 'الاقصر', 'Luxor', 1, NULL, NULL, NULL),
(8, 'البحر الاحمر', 'Red Sea', 1, NULL, NULL, NULL),
(9, 'البحيرة', 'Beheira ', 1, NULL, NULL, NULL),
(10, 'بني سويف', 'Beni Suef', 1, NULL, NULL, NULL),
(11, 'بورسعيد', 'Port Said', 1, NULL, NULL, NULL),
(12, 'جنوب سيناء', 'South Sinai', 1, NULL, NULL, NULL),
(13, 'الجيزة', 'Giza', 1, NULL, NULL, NULL),
(14, 'الدقهلية', 'Dakahlia', 1, NULL, NULL, NULL),
(15, 'دمياط', 'Damietta', 1, NULL, NULL, NULL),
(16, 'سوهاج', 'Sohag', 1, NULL, NULL, NULL),
(17, 'السويس', 'Suez', 1, NULL, NULL, NULL),
(18, 'الشرقية', 'Sharqia', 1, NULL, NULL, NULL),
(19, 'شمال سيناء', 'North Sinai', 1, NULL, NULL, NULL),
(20, 'الغربية', 'Gharbia', 1, NULL, NULL, NULL),
(21, 'الفيوم', 'Faiyum', 1, NULL, NULL, NULL),
(22, 'القليوبية', 'Qalyubia', 1, NULL, NULL, NULL),
(23, 'قنا', 'Qena', 1, NULL, NULL, NULL),
(24, 'كفر الشيخ', 'Kafr El Sheikh', 1, NULL, NULL, NULL),
(25, 'مطروح', 'Matruh', 1, NULL, NULL, NULL),
(26, 'المنوفية', 'Monufia', 1, NULL, NULL, NULL),
(27, 'المنيا', 'Minya', 1, NULL, NULL, NULL),
(28, 'الوادى الجديد', 'New Valley', 1, NULL, NULL, NULL),
(29, 'غير محدد', 'undefined', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqcategory_faq`
--

CREATE TABLE `faqcategory_faq` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `faq_id` bigint(20) UNSIGNED NOT NULL,
  `postion` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqcategory_faq`
--

INSERT INTO `faqcategory_faq` (`id`, `category_id`, `faq_id`, `postion`) VALUES
(1, 2, 8, 0),
(2, 1, 7, 7),
(3, 1, 6, 6),
(4, 1, 5, 5),
(5, 1, 4, 4),
(6, 1, 3, 3),
(7, 1, 2, 2),
(8, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_type` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `is_active`, `photo`, `photo_thum_1`, `url_type`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL, 0, NULL, '2024-01-04 08:28:12', '2024-01-04 08:28:12'),
(2, 1, NULL, NULL, 0, NULL, '2024-01-04 08:28:36', '2024-01-04 08:28:36'),
(3, 1, NULL, NULL, 0, NULL, '2024-01-04 08:29:06', '2024-01-04 08:29:06'),
(4, 1, NULL, NULL, 0, NULL, '2024-01-04 08:29:43', '2024-01-04 08:29:43'),
(5, 1, NULL, NULL, 0, NULL, '2024-01-04 08:30:28', '2024-01-04 08:30:28'),
(6, 1, NULL, NULL, 0, NULL, '2024-01-04 08:31:58', '2024-01-04 08:31:58'),
(7, 1, NULL, NULL, 0, NULL, '2024-01-04 08:32:37', '2024-01-04 08:32:37'),
(8, 1, NULL, NULL, 0, NULL, '2024-01-04 08:36:55', '2024-01-04 08:36:55');

-- --------------------------------------------------------

--
-- Table structure for table `faq_categories`
--

CREATE TABLE `faq_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faq_categories`
--

INSERT INTO `faq_categories` (`id`, `photo`, `photo_thum_1`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'images/faq-cat/1/da-web-player-xVF2Iaqit2.webp', 'images/faq-cat/1/da-web-player-mUioixtn2Y.webp', 1, NULL, '2024-01-04 08:20:16', '2024-01-04 14:52:03'),
(2, 'images/faq-cat/2/installation-IgI1hT6mvP.webp', 'images/faq-cat/2/installation-oaa6X7wyoW.webp', 1, NULL, '2024-01-04 08:21:49', '2024-01-04 14:50:39'),
(3, NULL, NULL, 1, NULL, '2024-01-04 08:22:07', '2024-01-04 08:22:07'),
(4, NULL, NULL, 1, NULL, '2024-01-04 08:22:16', '2024-01-04 08:22:16'),
(5, NULL, NULL, 1, NULL, '2024-01-04 08:22:27', '2024-01-04 08:22:27'),
(6, NULL, NULL, 1, NULL, '2024-01-04 08:22:38', '2024-01-04 08:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `faq_category_translations`
--

CREATE TABLE `faq_category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faq_category_translations`
--

INSERT INTO `faq_category_translations` (`id`, `category_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(1, 1, 'en', 'da-web-player', 'DA WEB PLAYER', NULL, 'DA WEB PLAYER', 'DA WEB PLAYER'),
(2, 2, 'en', 'installation', 'Installation', NULL, 'Installation', 'Installation'),
(3, 3, 'en', 'category-3', 'Category 3', NULL, 'Category 3', 'Category 3'),
(4, 4, 'en', 'category-4', 'Category 4', NULL, 'Category 4', 'Category 4'),
(5, 5, 'en', 'category-5', 'Category 5', NULL, 'Category 5', 'Category 5'),
(6, 6, 'en', 'category-6', 'Category 6', NULL, 'Category 6', 'Category 6');

-- --------------------------------------------------------

--
-- Table structure for table `faq_photos`
--

CREATE TABLE `faq_photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `faq_id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_extension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des_en` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des_es` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `file_h` int(11) DEFAULT NULL,
  `file_w` int(11) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `print_photo` int(11) NOT NULL DEFAULT 2,
  `is_default` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faq_photos`
--

INSERT INTO `faq_photos` (`id`, `faq_id`, `photo`, `photo_thum_1`, `photo_thum_2`, `file_extension`, `des_en`, `des_es`, `file_size`, `file_h`, `file_w`, `position`, `print_photo`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-D19MiSedaU.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-hgL5y68wEW.webp', NULL, NULL, '<p>1. Open your Roku device and click the following buttons on your remote :</p>\r\n\r\n<ul>\r\n	<li>Home button 3 times</li>\r\n	<li>Followed by the Up button twice</li>\r\n	<li>Then Right button once</li>\r\n	<li>Left button once</li>\r\n	<li>Right button once</li>\r\n	<li>Left button once</li>\r\n	<li>Right button once</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:03', '2024-01-04 11:17:16'),
(2, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-CdH2gH08je.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-buFv4LIZVH.webp', NULL, NULL, '<p>2. This will then launch the &ldquo;Developer Options&rdquo; screen<br />\r\n<span style=\"color:#e74c3c\"><strong>IMPORTANT </strong></span>: You must make note of the provided URL that we will use later.<br />\r\nIn this instance, the IP URL is&nbsp; http://192.168.1.22&nbsp; (Yours will be different)<br />\r\nClick Enable installer and restart</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:03', '2024-01-04 11:32:06'),
(3, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-8h4AhWePVa.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-LIXfutWwi2.webp', NULL, NULL, '<p>3. Scroll down and click I Agree to Developer Tools License Agreement</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:03', '2024-01-04 16:32:43'),
(4, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-Dks06YJaU2.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-dTI0yxUggR.webp', NULL, NULL, '<p>4. When prompted, enter a PIN Number of your choice and click Set password and reboot.&nbsp; (Remember the PIN, you will use it in step # 13)</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:03', '2024-01-04 11:33:35'),
(5, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-ex1Tsqoo8V.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-Qs9LFXqIFd.webp', NULL, NULL, '<p>5. Your device will restart</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:03', '2024-01-04 11:33:35'),
(6, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-rt8E489Lu9.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-PgKj8ZA0ix.webp', NULL, NULL, '<p>6. Enter the Developer Settings prompt again (step #1) to make sure Developer settings are enabled, if you see it exactly like the second picture below, you are fine and don&rsquo;t change anything, just leave it as it is and move to the next step.</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:23', '2024-01-04 11:33:35'),
(7, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-10oWvlbgSa.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-VgmypOrN7p.webp', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:23', '2024-01-04 08:47:23'),
(8, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-WpIeW2wJC7.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-gaMEsEWiQg.webp', NULL, NULL, '<p>7. Now open the internet browser on your computer and go to my.roku.com. Enter your account information and click Sign in. Create an account if you don&rsquo;t have one then login.</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:23', '2024-01-04 11:36:16'),
(9, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-irJgPZLJwk.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-qbe2KtAEUO.webp', NULL, NULL, '<p>8. Choose Add channel with a code</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:23', '2024-01-04 11:36:16'),
(10, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-8TFxJx3qWw.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-jH0Y1ebmYh.webp', NULL, NULL, '<p>9. Type iptvsmarters and then click &ldquo;Add Channel&rdquo;</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:23', '2024-01-04 11:36:16'),
(11, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-9Jbt5Jicng.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-CoaJxgDcVz.webp', NULL, NULL, '<p>10. Click OK</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:41', '2024-01-04 11:36:16'),
(12, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-IyRL2V5zI9.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-4bQTgH6sKS.webp', NULL, NULL, '<p>11. Click Yes, add channel</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:41', '2024-01-04 11:36:16'),
(13, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-j7FX7Lw8Xj.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-24IheLvuL1.webp', NULL, NULL, '<p>12. Next, you must download the IPTV Smarters file to your computer. You &lsquo;ll upload it later to your Roku device.<br />\r\nOn your computer open the internet browser and type,<br />\r\n<a href=\"https://dastreamz.net/roku.zip\">https://dastreamz.net/roku.zip</a>&nbsp;&nbsp; to start downloading the IPTV Smarters Roku App &ldquo;roku.zip&rdquo;,<br />\r\nOr<br />\r\nyou you can download it directly to your computer by clicking HERE and remember where you saved the downloaded file, you will need to browse and select it later in (step# 15).</p>\r\n\r\n<p>&nbsp;</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:41', '2024-01-04 11:36:16'),
(14, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-SdVL8CM7RL.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-klbPUAqxHT.webp', NULL, NULL, '<p>13. Now go to the IP URL from the step #2 above on your computer&rsquo;s internet browser and Sign In with username: rokudev and password is &gt; the PIN you created earlier in the step #4 above.<br />\r\nNote, Your IP URL is different than the one shown in the picture below.</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:41', '2024-01-04 11:36:16'),
(15, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-bONOzVfVys.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-xcx2kJaGUi.webp', NULL, NULL, '<p>14. Click Upload</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:41', '2024-01-04 11:37:56'),
(16, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-tlRjVF88Me.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-RPiI1IPV0d.webp', NULL, NULL, '<p>15. Choose the previously downloaded &ldquo;roku.zip&rdquo; file which downloaded in step #12 , select it and click &ldquo;Open&rdquo;</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:58', '2024-01-04 11:37:56'),
(17, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-pHQv3omMWg.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-kcAv9tdW5C.webp', NULL, NULL, '<p>16. Click Install</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:58', '2024-01-04 11:37:56'),
(18, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-vOV6wXVBPN.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-0UKyiRjyPl.webp', NULL, NULL, '<p>17. The App has been installed successfully</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:58', '2024-01-04 11:37:56'),
(19, 8, 'images/faq/8/how-to-install-iptv-smarters-on-roku-Qd5EjIr4qq.webp', 'images/faq/8/how-to-install-iptv-smarters-on-roku-vLRcepKNvj.webp', NULL, NULL, '<p>18. The IPTV Smarters App will automatically launch on your TV. Enter your service logins, and type <a href=\"http://3.prima-streams.store:80\">http://3.prima-streams.store:80</a> in the URL field, Check &ldquo;Remember me&rdquo; box, then click &ldquo;Login&rdquo;</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 08:47:58', '2024-01-04 11:37:56'),
(20, 4, 'images/faq/4/how-to-stream-the-service-using-da-web-player-zkiiNwlGiX.webp', 'images/faq/4/how-to-stream-the-service-using-da-web-player-XwEfMVVRD6.webp', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 11:41:47', '2024-01-04 11:41:47'),
(21, 5, 'images/faq/5/how-to-favourite-unfavourite-a-channel-in-da-web-player-l2jjuMYauJ.webp', 'images/faq/5/how-to-favourite-unfavourite-a-channel-in-da-web-player-lFPewHeUrx.webp', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 11:42:26', '2024-01-04 11:42:26'),
(22, 6, 'images/faq/6/can-i-set-a-parental-control-pin-in-da-web-player-UdFKn3lQvM.webp', 'images/faq/6/can-i-set-a-parental-control-pin-in-da-web-player-DhcZBHyOS5.webp', NULL, NULL, '<p>1- After you login to &quot;DA WEB PLAYER&quot;, on the Homepage, click the &quot;Settings&quot; gear icon which is located on the top-right corner</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 11:43:07', '2024-01-04 11:44:22'),
(23, 6, 'images/faq/6/can-i-set-a-parental-control-pin-in-da-web-player-gEupDCH7eA.webp', 'images/faq/6/can-i-set-a-parental-control-pin-in-da-web-player-NMmHjEkMEa.webp', NULL, NULL, '<p>2- Click &quot;Parental Control&quot;</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 11:43:07', '2024-01-04 11:45:08'),
(24, 6, 'images/faq/6/can-i-set-a-parental-control-pin-in-da-web-player-nd2Bn8svTp.webp', 'images/faq/6/can-i-set-a-parental-control-pin-in-da-web-player-URVoLwkLo8.webp', NULL, NULL, '<p>3- Enter a 4 digits PIN then click &quot;NEXT&quot;</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 11:43:07', '2024-01-04 11:45:08'),
(25, 6, 'images/faq/6/can-i-set-a-parental-control-pin-in-da-web-player-hV0FCnbCKp.webp', 'images/faq/6/can-i-set-a-parental-control-pin-in-da-web-player-jN1DXWUAWl.webp', NULL, NULL, '<p>4- Confirm the same 4 digits PIN then click &quot;SAVE&quot;</p>', NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 11:44:32', '2024-01-04 16:09:15'),
(26, 7, 'images/faq/7/how-to-search-for-a-channel-movie-or-series-in-da-web-player-Q2JcoLpAJj.webp', 'images/faq/7/how-to-search-for-a-channel-movie-or-series-in-da-web-player-rq1n4owUIY.webp', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 11:45:51', '2024-01-04 11:45:51'),
(27, 7, 'images/faq/7/how-to-search-for-a-channel-movie-or-series-in-da-web-player-0h1gJzsleS.webp', 'images/faq/7/how-to-search-for-a-channel-movie-or-series-in-da-web-player-RrbOY6cXbs.webp', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 0, '2024-01-04 11:45:51', '2024-01-04 11:45:51');

-- --------------------------------------------------------

--
-- Table structure for table `faq_translations`
--

CREATE TABLE `faq_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `faq_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faq_translations`
--

INSERT INTO `faq_translations` (`id`, `faq_id`, `locale`, `slug`, `name`, `des`, `other`, `g_title`, `g_des`) VALUES
(1, 1, 'en', 'what-is-da-web-player', 'What is \"DA WEB PLAYER\" ?', '<p>It is a web application to stream the service through your web browser without installing any additional apps.</p>', NULL, NULL, NULL),
(2, 2, 'en', 'what-browsers-support-da-web-player', 'What browsers support \"DA WEB PLAYER\" ?', '<p>All web browsers such as Google Chrome, Safari, Microsoft Edge, Mozilla Firefox or any other web browser are supporting &quot;DA WEB PLAYER&quot;</p>', NULL, NULL, NULL),
(3, 3, 'en', 'what-are-the-devices-which-support-da-web-player', 'What are the devices which support \"DA WEB PLAYER\" ?', '<p>All devices have a web browser are supporting &quot;DA WEB PLAYER&quot;. For example:<br />\r\nAndroid phones and tablets<br />\r\niOS devices such as iPhones and iPads<br />\r\nMAC computers<br />\r\nMicrosoft Windows computers<br />\r\nPlayStation<br />\r\nXbox</p>', NULL, NULL, NULL),
(4, 4, 'en', 'how-to-stream-the-service-using-da-web-player', 'How to stream the service using \"DA WEB PLAYER\" ?', '<p>It&#39;s pretty simple, just copy and paste in your web browser&gt;&gt;<br />\r\n<a href=\"http://dastreamz-player.xyz:8080/webplayer\" target=\"_blank\">http://dastreamz-player.xyz:8080/webplayer</a><br />\r\nType any name from your choice in the &quot;Any Name&quot; field<br />\r\nEnter your service Username<br />\r\nEnter your service Password<br />\r\nHit &quot;ADD USER&quot;</p>', NULL, NULL, NULL),
(5, 5, 'en', 'how-to-favourite-unfavourite-a-channel-in-da-web-player', 'How to favourite /unfavourite a channel in \"DA WEB PLAYER\" ?', '<p>Simply, stop on the channel that you want to add to Favourite, and click the white heart symbol.<br />\r\nClick the heart symbol again to remove the channel from the favourite list.</p>', NULL, NULL, NULL),
(6, 6, 'en', 'can-i-set-a-parental-control-pin-in-da-web-player', 'Can I set a Parental Control PIN in \"DA WEB PLAYER\" ?', '<p>Yes, you can by doing the following :</p>', NULL, NULL, NULL),
(7, 7, 'en', 'how-to-search-for-a-channel-movie-or-series-in-da-web-player', 'How to search for a channel, movie, or  series in \"DA WEB PLAYER\" ?', '<p>You can search for a specific channel, movie, or&nbsp; series. For example you can search for &quot;FOX NEWS&quot; channel by clicking the &quot;Master Search&quot; which is located in the top right corner of the main home page, and type-in &quot;FOX NEWS&quot; then click the &quot;Search&quot; button, same concept when searching for a movie or a series.</p>', NULL, NULL, NULL),
(8, 8, 'en', 'how-to-install-iptv-smarters-on-roku', 'How to Install IPTV Smarters on Roku ?', '<p>The following tutorial will provide you with step-by-step instructions to install the IPTV Smarters app on a Roku device for your live streaming needs.<br />\r\nBecause Roku uses a closed source system, we must &ldquo;sideload&rdquo; the IPTV app onto this device for use.<br />\r\nThis will require the use of a computer in order to download the IPTV app file and add it to your Roku streaming device.<br />\r\nWe always recommend using an Android-powered device such as a Firestick, Fire TV, or An android Box because of its open-source system.</p>\r\n\r\n<p>&nbsp;</p>', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(998, '2014_10_12_000000_create_users_table', 1),
(999, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(1000, '2014_10_12_100000_create_password_resets_table', 1),
(1001, '2019_08_19_000000_create_failed_jobs_table', 1),
(1002, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(1003, '2023_06_24_105531_create_settings_table', 1),
(1004, '2023_06_24_144232_create_setting_translations_table', 1),
(1005, '2023_06_29_193744_create_def_photos_table', 1),
(1006, '2023_06_29_235416_create_upload_filters_table', 1),
(1007, '2023_07_03_115945_create_upload_filter_sizes_table', 1),
(1008, '2023_07_12_171931_create_permission_tables', 1),
(1009, '2023_07_14_112208_add_names_roles_table', 1),
(1010, '2023_07_14_115125_add_names_permissions_table', 1),
(1011, '2023_08_24_145512_create_web_privacies_table', 1),
(1012, '2023_08_24_145811_create_web_privacy_translations_table', 1),
(1013, '2023_08_27_120554_create_faq_categories_table', 1),
(1014, '2023_08_27_120612_create_faq_category_translations_table', 1),
(1015, '2023_08_27_120635_create_faqs_table', 1),
(1016, '2023_08_27_120656_create_faq_translations_table', 1),
(1017, '2023_08_29_091745_create_pages_table', 1),
(1018, '2023_08_29_091812_create_page_translations_table', 1),
(1019, '2023_09_16_123303_create_faqcategory_faq_table', 1),
(1020, '2023_09_23_143553_create_shoppingcart_table', 1),
(1021, '2023_09_28_141144_create_users_customers_table', 1),
(1022, '2023_09_29_143600_create_data_cities_table', 1),
(1023, '2023_10_04_055847_create_news_letters_table', 1),
(1024, '2023_10_07_163342_create_contact_us_forms_table', 1),
(1025, '2024_01_03_135137_create_faq_photos_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(2, 'App\\Models\\User', 3);

-- --------------------------------------------------------

--
-- Table structure for table `news_letters`
--

CREATE TABLE `news_letters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `cat_id`, `photo`, `photo_thum_1`, `is_active`, `postion`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'home', NULL, NULL, 1, 0, NULL, '2024-01-02 12:40:43', '2024-01-02 12:46:54'),
(2, 'ContactUs', NULL, NULL, 1, 0, NULL, '2024-01-02 15:09:09', '2024-01-02 15:09:09'),
(3, 'FaqList', NULL, NULL, 1, 0, NULL, '2024-01-02 15:27:38', '2024-01-02 15:29:32');

-- --------------------------------------------------------

--
-- Table structure for table `page_translations`
--

CREATE TABLE `page_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_translations`
--

INSERT INTO `page_translations` (`id`, `page_id`, `locale`, `name`, `g_title`, `g_des`) VALUES
(1, 1, 'en', 'Home Page', 'Home Page', 'Home Page'),
(2, 1, 'es', 'Home Page', 'Home Page', 'Home Page'),
(3, 2, 'en', 'Contact Us', 'Contact Us', 'Contact Us'),
(4, 2, 'es', 'Contact Us', 'Contact Us', 'Contact Us'),
(5, 3, 'en', 'Faq', 'Faq', 'Faq'),
(6, 3, 'es', 'Faq', 'Faq', 'Faq');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `cat_id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'users_view', 'عرض', 'View', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(2, 1, 'users_add', 'اضافة', 'Add', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(3, 1, 'users_edit', 'تعديل', 'Edit', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(4, 1, 'users_delete', 'حذف', 'Delete', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(5, 2, 'roles_view', 'عرض', 'View', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(6, 2, 'roles_add', 'اضافة', 'Add', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(7, 2, 'roles_edit', 'تعديل', 'Edit', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(8, 2, 'roles_delete', 'حذف', 'Delete', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(9, 2, 'roles_update_permissions', 'تعديل صلاحيات المجموعة', 'Roles Update Permissions', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(10, 3, 'permissions_view', 'عرض', 'View', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(11, 3, 'permissions_add', 'اضافة', 'Add', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(12, 3, 'permissions_edit', 'تعديل', 'Edit', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(13, 3, 'permissions_delete', 'حذف', 'Delete', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(14, 4, 'webPrivacy_view', 'عرض', 'View', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(15, 4, 'webPrivacy_add', 'اضافة', 'Add', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(16, 4, 'webPrivacy_edit', 'تعديل', 'Edit', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(17, 4, 'webPrivacy_delete', 'حذف', 'Delete', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(18, 5, 'adminlang_view', 'عرض ملفات لغة التحكم', 'View Admin Lang', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(19, 5, 'adminlang_edit', 'تعديل ملفات لغة التحكم', 'Edit Admin Lang', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(20, 5, 'weblang_view', 'عرض ملفات لغة الموقع', 'View', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(21, 5, 'weblang_edit', 'تعديل ملفات لغة الموقع', 'Edit', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(22, 6, 'config_section', 'عرض الاعدادات', 'Setting View', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(23, 6, 'website_config', 'اعدادات الموقع', 'Web Site Setting', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(24, 7, 'defPhoto_view', 'عرض', 'View', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(25, 7, 'defPhoto_add', 'اضافة', 'Add', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(26, 7, 'defPhoto_edit', 'تعديل', 'Edit', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(27, 7, 'defPhoto_delete', 'حذف', 'Delete', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(28, 8, 'upFilter_view', 'عرض', 'View', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(29, 8, 'upFilter_add', 'اضافة', 'Add', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(30, 8, 'upFilter_edit', 'تعديل', 'Edit', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(31, 8, 'upFilter_delete', 'حذف', 'Delete', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(32, 9, 'Pages_view', 'عرض', 'View', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(33, 9, 'Pages_add', 'اضافة', 'Add', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(34, 9, 'Pages_edit', 'تعديل', 'Edit', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(35, 9, 'Pages_delete', 'حذف', 'Delete', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(36, 9, 'Pages_restore', 'استعادة المحذوف', 'Restore', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(37, 9, 'Pages_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(38, 15, 'Faq_view', 'عرض', 'View', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(39, 15, 'Faq_add', 'اضافة', 'Add', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(40, 15, 'Faq_edit', 'تعديل', 'Edit', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(41, 15, 'Faq_delete', 'حذف', 'Delete', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(42, 15, 'Faq_restore', 'استعادة المحذوف', 'Restore', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54'),
(43, 15, 'Faq_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2024-01-04 08:42:54', '2024-01-04 08:42:54');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'ادمن كامل الصلاحيات', 'Full Admin Permission ', 'web', '2024-01-04 08:42:55', '2024-01-04 08:42:55'),
(2, 'editor', 'محرر', 'editor', 'web', '2024-01-04 08:42:55', '2024-01-04 08:42:55');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

CREATE TABLE `shopping_cart` (
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instance` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `photo`, `photo_thum_1`, `roles_name`, `status`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Hany Darwish ', 'hany.freestyle4u@gmail.com', NULL, NULL, NULL, '[\"admin\"]', 1, NULL, '$2y$10$0YtegTTOTzF6jrWlFUad5uTxXfwKm3fq.ybXCX9SJHUBuTW8zPB92', NULL, '2024-01-04 08:42:55', '2024-01-04 08:42:55'),
(2, 'Sub Admin  ', 'subadmin@test.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$L0vMgzJJAVNaq5s17aUB4eumoUtNXYwb7vNRB0OC.oHneZsdCfOtu', NULL, '2024-01-04 08:42:55', '2024-01-04 08:42:55'),
(3, 'Editor', 'editor@test.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$ZCGL//04OodPiNktfm4Xbu7DV3yfwXNKJcyYfdZnm/NGYZUFbcF0C', NULL, '2024-01-04 08:42:55', '2024-01-04 08:42:55');

-- --------------------------------------------------------

--
-- Table structure for table `users_customers`
--

CREATE TABLE `users_customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `land_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_temp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_customers`
--

INSERT INTO `users_customers` (`id`, `name`, `company_name`, `email`, `phone`, `whatsapp`, `land_phone`, `city_id`, `status`, `is_active`, `photo`, `photo_thum_1`, `email_verified_at`, `password`, `password_temp`, `last_login`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'احمد عتمان', 'عتمان جروب', 'etmano@hotmail.com', '01223129660', '01223129660', '4867311', 3, 1, 1, NULL, NULL, NULL, '$2y$10$sLfSr0tHo64x7IZKKpngeeaFOx21kJPqxZSRKRe6xKPD1y5kKGb7.', NULL, '2023-10-05 22:02:19', NULL, '2023-09-29 12:06:43', '2023-10-05 19:02:19', NULL),
(2, 'هانى درويش', 'فري ستايل', NULL, '01221563252', '01221563252', NULL, 3, 1, 1, NULL, NULL, NULL, '$2y$10$MHBY2M/C3svXIUBJLh2mQOXTisysi0KtukM8CTPKORjEzDq5gUDWy', '01221563252@5604', NULL, NULL, '2023-10-05 04:21:30', '2023-10-05 16:21:07', NULL),
(3, 'محمد أنور', 'عتمان جروب', NULL, '01117777093', NULL, NULL, 3, 1, 1, NULL, NULL, NULL, '$2y$10$Iz3a3.vJliK..EAPlQeY/OIVLXTwC21EhBbG03SF4Z3vmO5MoD2Ou', '01117777093@6067', NULL, NULL, '2023-10-05 04:22:44', '2023-10-05 17:01:33', NULL),
(4, 'أحمد جمعة', 'عتمان جروب', NULL, '01096693772', NULL, NULL, 3, 1, 1, NULL, NULL, NULL, '$2y$10$vSYuKgMW2KaDbGrS4bxcIu1sY8dyZddJo4aDENOPk2g2S5d73o44i', '01096693772@6481', NULL, NULL, '2023-10-05 04:24:01', '2023-10-05 04:24:01', NULL),
(5, 'ايمن بكر', 'عتمان جروب', NULL, '01032977744', NULL, NULL, 3, 1, 1, NULL, NULL, NULL, '$2y$10$/xOxaTH0s3BW7ZoITRXWUOso8/632JWOB7eI0koTxklSSTJa5s/4q', '01032977744@6528', NULL, NULL, '2023-10-05 04:25:10', '2023-10-05 04:25:10', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_settings`
--
ALTER TABLE `config_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_setting_translations_setting_id_locale_unique` (`setting_id`,`locale`),
  ADD KEY `config_setting_translations_locale_index` (`locale`);

--
-- Indexes for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `config_upload_filter_sizes_filter_id_foreign` (`filter_id`);

--
-- Indexes for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_web_privacy_translations_privacy_id_locale_unique` (`privacy_id`,`locale`),
  ADD KEY `config_web_privacy_translations_locale_index` (`locale`);

--
-- Indexes for table `contact_us_forms`
--
ALTER TABLE `contact_us_forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_cities`
--
ALTER TABLE `data_cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `data_cities_name_unique` (`name`),
  ADD UNIQUE KEY `data_cities_name_en_unique` (`name_en`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `faqcategory_faq`
--
ALTER TABLE `faqcategory_faq`
  ADD PRIMARY KEY (`id`),
  ADD KEY `faqcategory_faq_category_id_foreign` (`category_id`),
  ADD KEY `faqcategory_faq_faq_id_foreign` (`faq_id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq_categories`
--
ALTER TABLE `faq_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq_category_translations`
--
ALTER TABLE `faq_category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `faq_category_translations_category_id_locale_unique` (`category_id`,`locale`),
  ADD UNIQUE KEY `faq_category_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `faq_category_translations_locale_index` (`locale`);

--
-- Indexes for table `faq_photos`
--
ALTER TABLE `faq_photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `faq_photos_faq_id_foreign` (`faq_id`);

--
-- Indexes for table `faq_translations`
--
ALTER TABLE `faq_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `faq_translations_faq_id_locale_unique` (`faq_id`,`locale`),
  ADD UNIQUE KEY `faq_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `faq_translations_locale_index` (`locale`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `news_letters`
--
ALTER TABLE `news_letters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `news_letters_email_unique` (`email`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_cat_id_unique` (`cat_id`);

--
-- Indexes for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_translations_page_id_locale_unique` (`page_id`,`locale`),
  ADD KEY `page_translations_locale_index` (`locale`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD PRIMARY KEY (`identifier`,`instance`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `users_customers`
--
ALTER TABLE `users_customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_customers_phone_unique` (`phone`),
  ADD UNIQUE KEY `users_customers_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `config_settings`
--
ALTER TABLE `config_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `contact_us_forms`
--
ALTER TABLE `contact_us_forms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `data_cities`
--
ALTER TABLE `data_cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqcategory_faq`
--
ALTER TABLE `faqcategory_faq`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `faq_categories`
--
ALTER TABLE `faq_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `faq_category_translations`
--
ALTER TABLE `faq_category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `faq_photos`
--
ALTER TABLE `faq_photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `faq_translations`
--
ALTER TABLE `faq_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1026;

--
-- AUTO_INCREMENT for table `news_letters`
--
ALTER TABLE `news_letters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `page_translations`
--
ALTER TABLE `page_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users_customers`
--
ALTER TABLE `users_customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD CONSTRAINT `config_setting_translations_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `config_settings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD CONSTRAINT `config_upload_filter_sizes_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `config_upload_filters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD CONSTRAINT `config_web_privacy_translations_privacy_id_foreign` FOREIGN KEY (`privacy_id`) REFERENCES `config_web_privacies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faqcategory_faq`
--
ALTER TABLE `faqcategory_faq`
  ADD CONSTRAINT `faqcategory_faq_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `faq_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `faqcategory_faq_faq_id_foreign` FOREIGN KEY (`faq_id`) REFERENCES `faqs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faq_category_translations`
--
ALTER TABLE `faq_category_translations`
  ADD CONSTRAINT `faq_category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `faq_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faq_photos`
--
ALTER TABLE `faq_photos`
  ADD CONSTRAINT `faq_photos_faq_id_foreign` FOREIGN KEY (`faq_id`) REFERENCES `faqs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faq_translations`
--
ALTER TABLE `faq_translations`
  ADD CONSTRAINT `faq_translations_faq_id_foreign` FOREIGN KEY (`faq_id`) REFERENCES `faqs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD CONSTRAINT `page_translations_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
